public class C2 {
	public static void main(String[] args) {
		System.exit(1);
	}
}
